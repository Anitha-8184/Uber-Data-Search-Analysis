<?php
include("connection.php");

//if($result){
  //echo"connected";
//}
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Weekly', 'Rides'],
         <?php
          $sql="SELECT *FROM rides";
          $fire=mysqli_query($conn,$sql);
        
            while($result=mysqli_fetch_array($fire)){
              echo "['".$result['Weekly']."',".$result['Rides']."],";
          
          }
          ?>
        ]);

        var options = {
          chart: {
            title: 'Weekly Rides',
          },
          bars: 'vertical' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>
    <div id="barchart_material" style="width: 900px; height: 500px;"></div>
  </body>
</div>
</html>