<?php


$username = $_POST['username'];
$password = $_POST['password'];




//database connection
   $conn = new mysqli('localhost','root','','uber');
   if ($conn->connect_error) {
      die('Connection failed:' .$conn->connect_error);
   }else{

          $stmt = $conn->prepare("SELECT * from uberuser where username= ?");
          $stmt->bind_param("s", $username);
          $stmt->execute();
          $stmt_result= $stmt->get_result();

         if ($stmt_result->num_rows > 0)
          {
            $data = $stmt_result->fetch_assoc();
         }
         if($data['password'] === $password)  
         {
          
           header('location:usearch.php');
         }     
}
      
          if($data['password'] !== $password)
           {
            echo '<script>alert("INvalid password")</script>';            
          }
       

?>
<h1>Try to login again</h1>
<a href = "uuser.php">login again</a>