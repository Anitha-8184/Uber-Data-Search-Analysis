<?php
$username = "root";
$password = "";
$server = "localhost";
$db = "uber";

$conn = mysqli_connect($server, $username, $password, $db);

if($conn){

	?>
	<script>
		//alert('connection successful');
	</script>
	<?php
}else{
	die("no connection" . mysqli_connect_error());
}