<html>
<head>
<title>uber details</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="menu-bar">
    <ul>
        <li><a href="uhome.php">Home</a></li>
        <li><a href="uadmin.php">Admin</a></li>
              <div class="Sub-menu-1">
                <ul>
             <li><a href="uberdetails.php">Uber Details</a></li>
             <li><a href="Rides.php">Rides</a></li>
             <li><a href="Ridedetails.php">Ride Details</a></li>
             <li><a href="uadmin.php">log out</a></li>
                </ul>
        </div>
    </ul>
    </div>
    <div>
        <h2 href="uadmin.php">Rides</h2>
    </div>
    <form method="POST" action="addingrides.php">
    <div>
     <label><b>Hourly:</b></label><input type="text" name="Hourly" /><br><br>
     <label><b>HRides:</b></label><input type="text" name="HRides" /><br><br>
     <label><b>Daywise:</b></label><input type="text" name="Daywise" /><br><br>
     <label><b>DRides:</b></label><input type="text" name="DRides" /><br><br>
     <label><b>Passengers:</b></label><input type="text" name="Passengers" /><br><br>
     <label><b>Weekly:</b></label><input type="text" name="Weekly" /><br><br>
     <label><b>Rides:</b></label><input type="text" name="Rides" /><br><br>
       <button type="ADD" id="ADD-btn">ADD</button>
    </div>
    </form>
   </body>
</html>