<html>
<head>
<title>uber details</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="menu-bar">
    <ul>
        <li><a href="uhome.php">Home</a></li>
        <li><a href="uadmin.php">Admin</a></li>
              <div class="Sub-menu-1">
                <ul>
             <li><a href="uberdetails.php">Uber Details</a></li>
             <li><a href="Rides.php">Rides</a></li>

             <li><a href="uadmin.php">log out</a></li>
                </ul>
        </div>
    </ul>
    </div>
    <div>
        <h2 href="uadmin.php">Uber Details</h2>
    </div>
    <form method="POST" action="addingdetails.php">
    <div>
     <label><b>Uber Services:</b></label><input type="text" name="uber services" /><br><br>
     <label><b>Availability :</b></label><input type="text" name="Availability" /><br><br>
     <label><b>Starting point:</b></label><input type="text" name="Starting point" /><br><br>
     <label><b>Destination point:</b></label><input type="text" name="Destination point" /><br><br>
     <label><b>Date:</b></label><input type="date" name="Date" /><br><br>
     <label><b>Time:</b></label><input type="time" name="Time" /><br><br>
       <button type="ADD" id="ADD-btn">ADD</button>
    </div>
    </form>
   </body>
</html>