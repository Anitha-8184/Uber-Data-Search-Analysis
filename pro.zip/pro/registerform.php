<?php


$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$DOB = $_POST['DOB'];
$gender = $_POST['gender'];
$mobileno = $_POST['mobileno'];
//$role = $_POST['role'];
//database connection
    f

   $conn = new mysqli('localhost','root','','uber');
   if ($conn->connect_error) {
    die('Connection failed:' .$conn->connect_error);
   }

   else  {
     
   $stmt =$conn->prepare("INSERT INTO uberuser(username, password, email, DOB, gender, mobileno) VALUES(?, ?, ?, ?, ?, ?) ");
    $stmt->bind_param("ssssss",$username, $password, $email, $DOB, $gender, $mobileno);
    $stmt->execute();
    echo '<script>alert("Registration Successfully")</script>';
    $stmt->close();
    $conn->close();
    
   
 }
   
  
?>
<?php header('location:uuser.php');?>