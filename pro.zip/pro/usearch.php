<html>
<head>
<title>user registration page design</title>
<link rel="stylesheet" href="style.css">
<style>
    body{
        background-image: url(uber1.jpeg);
    }
    </style>
</head>
<body>
    <div class="menu-bar">
        <ul> <li><a href="uhome.php">Home</a></li>
    
    <li><a href="uberdetails.php">Information</a></li>
               <div class="Sub-menu-1">
                <ul>
                    <li><a href="world1.php">World</a></li>
                    <li><a href="India.php">India</a></li>
                    <li><a href="graph1.php">Hour</a></li>
                    <li><a href="day.php">Day</a></li>
                    <li><a href="weekly.php">Week</a></li>
                    <li><a href="uuser.php">logout</a></li>

                </ul>
             </div>

        </ul>
    </div>
</body>
</html 