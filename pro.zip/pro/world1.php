<?php
$connection=mysqli_connect("localhost","root","","uber");

//if($connection)
//{
 // echo "success";
//}
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {
        'packages':['geochart'],
        'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
      });
      google.charts.setOnLoadCallback(drawRegionsMap);

      function drawRegionsMap() {
        var data = google.visualization.arrayToDataTable([
          ['uber_services', 'Availability'],
         <?php
         $sql="SELECT * FROM data";
         $fire =mysqli_query($connection,$sql);
         while($result=mysqli_fetch_assoc($fire)){
          echo"['".$result['uber_services']."',".$result['Availability']."],";
         }
         ?>
        ]);

        var options = {
        colorAxis: {colors: ['deeppink','yellow', 'cyan']}
        };

        var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="regions_div" style="width: 900px; height: 500px;"></div>
  </body>
</html>
