<?php
include("connection.php");

$uber_services= $_POST['uber_services'];
$Availability= $_POST['Availability'];
$Starting_point= $_POST['Starting_point'];
$Destination_point= $_POST['Destination_point'];
$Date1= $_POST['Date'];
$Time1= $_POST['Time'];

//$role = $_POST['role'];
//database connection
   echo $Date1."<br>";
   echo $Time1;

   //$conn = new mysqli('localhost','root','','uber');
   if ($conn->connect_error) {
   	die('Connection failed:' .$conn->connect_error);
   }else  {
   	 $query="INSERT INTO data VALUES('$uber_services', '$Availability', '$Starting_point', '$Destination_point', '$Date1', '$Time1');";
	$result=mysqli_query($conn,$query);
	echo "Successfull";
  /* $stmt =$conn->prepare("INSERT INTO data(uber_services, Availability, Starting_point, Destination_point, Date1, Time1) VALUES(?, ?, ?, ?, ?, ?) ");
   	$stmt->bind_param($uber_services, $Availability, $Starting_point, $Destination_point, $Date1, $Time1);
   	$stmt->execute();
   	echo '<script>alert("Added Successfully")</script>';
   	$stmt->close();
   	$conn->close();
	   */
    
   }  
?>
<?php  header('location:udata.php')?>