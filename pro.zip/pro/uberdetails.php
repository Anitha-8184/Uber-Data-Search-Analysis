<!DOCTYPE html>
<html>
<head>
	<title>Table</title>
<link rel="stylesheet" href="style1.css">
</head>
<body>

<div class="main-div">
	<h1>UBER DETAILS</h1>

	<div class="center-div">
		<div class="table-responsive">
			<table>
				<thead>
					<tr>
						<th>id</th>
			            <th>Uber Services</th>
				        <th>Availability</th>
				        <th>Starting point</th>
				        <th>Destination point</th>
				        <th>Date</th>
				        <th>Time</th>
				    </tr>
				</thead>

				<tbody>
<?php

include 'connection.php';

$selectquery = "select * from data ";

$query = mysqli_query($conn,$selectquery);

$num =mysqli_num_rows($query);

$res = mysqli_fetch_array($query);
$count=1;
while($res = mysqli_fetch_array($query))
{
   ?>

	<tr>
		<td><?php echo $count ?></td>
		<td><?php echo $res['uber_services'] ?></td>
		<td><?php echo $res['Availability'] ?></td>
		<td><?php echo $res['Starting_point'] ?></td>
		<td><?php echo $res['Destination_point'] ?></td>
		<td><?php echo $res['Date'] ?></td>
		<td><?php echo $res['Time'] ?></td>
	</tr>
<?php
$count++;
}

?>
					
				</tbody>
			</table>
</div>
</body>
</html>