<html>
<head>
<title>Homepage design</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="menu-bar">
    <ul>
    <li class="active"><a href="uhome.php">Home</a></li>
    <li><a href="uadmin.php">Admin</a></li>
    <li><a href="uuser.php">User</a></li>
    </ul>
    </div>
    <div>
    <h1 href="uhome.php">Welcome to Uber Data Search</h1></div>
</body>
</html>