<html>
  <head>
    <script type='text/javascript' src='https://www.gstatic.com/charts/loader.js'></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
</head>
<body>
<div id="visualization" style="margin: 1em"> </div>

<script>
google.load('visualization', '1', {'packages': ['geochart']});
google.setOnLoadCallback(drawVisualization);

function drawVisualization() {
  var data = google.visualization.arrayToDataTable([
    ['State', 'Rides'],
    ['Uttar Pradesh', 19985],
    ['Maharashtra', 11237],
    ['Bihar', 10380],
    ['West Bengal', 91347],
    ['Madhya Pradesh', 7259],
    ['Tamil Nadu', 7213],
    ['Rajasthan', 6862],
    ['Karnataka', 6113],
    ['Gujarat', 5038],
    ['Andhra Pradesh', 4938],
    ['Odisha', 10],
    ['Telangana', 3528],
    ['Kerala', 3338],
    ['Jharkhand', 32966],
    ['Assam', 3116],
    ['Punjab', 27704],
    ['Chhattisgarh', 25540],
    ['Haryana', 25353],
    ['Jammu and Kashmir', 1254],
    ['Uttarakhand', 10116],
    ['Himachal Pradesh', 68565],
    ['Tripura', 3671],
    ['Meghalaya', 2964],
    ['Manipur', 2721],
    ['Nagaland', 1980],
    ['Goa', 1459],
    ['Arunachal Pradesh', 13829],
    ['Mizoram', 10910],
    ['Sikkim', 6076],
    ['Delhi', 16758],
    ['Puducherry', 1244],
    ['Chandigarh', 10546],
    ['Andaman and Nicobar Islands', 3799],
    ['Dadra and Nagar Haveli', 3428],
    ['Daman and Diu', 24291],
    ['Lakshadweep', 644]
  ]);
  
  var opts = {
    region: 'IN',
    displayMode: 'regions',
    resolution: 'provinces',
    width: 640, 
    height: 480,
    colorAxis: {colors: ['yellow', 'green']}
  };
  var geochart = new google.visualization.GeoChart(
      document.getElementById('visualization'));
  geochart.draw(data, opts);
};

</script>
</body>
</html>