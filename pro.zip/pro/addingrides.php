<?php
include("connection.php");
$id=1;
$Hourly= (int)$_POST['Hourly'];
$HRides= (int)$_POST['HRides'];
$Daywise= (int)$_POST['Daywise'];
$DRides= (int)$_POST['DRides'];
$Passengers= (int)$_POST['Passengers'];
$Weekly= (int)$_POST['Weekly'];
$Rides= (int)$_POST['Rides'];

//$role = $_POST['role'];
//database connection
   

   $conn = new mysqli('localhost','root','','uber');
   if ($conn->connect_error) {
   	die('Connection failed:' .$conn->connect_error);
   }else  {
   	 
   $query="INSERT INTO rides VALUES('$id','$Hourly', '$HRides', '$Daywise', '$DRides','$Passengers', '$Weekly', '$Rides');";
   	$result=mysqli_query($conn,$query);
   }
   
  
?>
<?php  header('location:Rides.php')?>