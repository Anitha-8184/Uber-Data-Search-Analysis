<html>
<head>
<title>user registration page design</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="menu-bar">
    <ul>
    <li><a href="uhome.php">Home</a></li>
    <li><a href="uadmin.php">Admin</a></li>
    <li><a href="uuser.php">User</a></li>
    </ul>
    </div>
    <div class="Register Here">
    </div>
    <h2 href="uregistration.php">User Registration Login</h2>
    <form action="registerform.php" method="POST">
     <label><b>Username :</b></label>
     <input type="text" name="username" placeholder="username" /><br/><br/>
     <label><b>Password :</b></label>     
     <input type="password" placeholder="password" name="password" /><br/><br/>
     
     <label><b> Email-ID :</b></label>     
           <input type="email" placeholder="email" name="email"/><br/><br/>
     <label><b>Date Of Birth:</b></label>  
           <input type="date" placeholder="date" name="DOB"/><br/><br/>
           <label><b>Gender:</b></label>  
           <input type="gender" placeholder="gender" name="gender"/><br/><br/>
     <label><b>Mobile Number : </b></label>      
           <input type="text" placeholder="Mobile Number" name="mobileno"/><br/><br/>
     <button type="Register" id="Register-btn">Register</button>
    </form>
</body>