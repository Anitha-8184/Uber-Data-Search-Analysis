<html>
<head>
<title>admin page design</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="menu-bar">
    <ul>
    <li><a href="uhome.php">Home</a></li>
    <li><a href="uadmin.php">Admin</a></li>
    <li><a href="uuser.php">User</a></li>
    </ul>
    </div>
    <div>
        <h2 href="uadmin.php">Admin Login</h2>
    </div>
    <form method="post" action="uadminlogin.php">
    <div>
     <label for="username"><b>username :</b></label><input type="text" name="username"  required=""><br><br>
     <label for="password"><b>password :</b></label><input type="password" name="password"  required=""><br><br>
        <button type="login" id="login-btn">Login</button>
    </div>
    </form>
   </body>
</html>