<html>
<head>
<title>user page design</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="menu-bar">
    <ul>
    <li><a href="uhome.php">Home</a></li>
    <li><a href="uadmin.php">Admin</a></li>
    <li><a href="uuser.php">User</a></li>
    </ul>
    </div>
    <div>
        <h2 href="uuser.php">User Login</h2>
    </div>
    <form action="uuserlogin.php" method="POST">
    <div>
     <label for="username"><b>Username :</b></label><input type="text" name="username" required="" /><br/><br/>
     <label for="password"><b>Password :</b></label><input type="password" name="password" required="" /><br/><br/>
        <button type="login" id="login-btn">Login</button>
    </div>
         <c>
             New User?<a href="uregistration.php">Register Here</a>
         </c>
    </form>
   </body>
</html>