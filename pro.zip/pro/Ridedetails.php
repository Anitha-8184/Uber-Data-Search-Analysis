<!DOCTYPE html>
<html>
<head>
	<title>Table</title>
<link rel="stylesheet" href="style1.css">
</head>
<body>

<div class="main-div">
	<h1>RIDE DETAILS</h1>

	<div class="center-div">
		<div class="table-responsive">
			<table>
				<thead>
					<tr>
						<th>id</th>
			            <th>Hourly</th>
				        <th>Hour Rides</th>
				        <th>Daywise</th>
				        <th>Day Rides</th>
				        <th>Passengers</th>
				        <th>Weekly</th>
				        <th>Week Rides</th>
				    </tr>
				</thead>

				<tbody>
<?php

include 'connection.php';

$selectquery = "select * from Rides ";

$query = mysqli_query($conn,$selectquery);

$num =mysqli_num_rows($query);

$res = mysqli_fetch_array($query);

while($res = mysqli_fetch_array($query))
{
   ?>

	<tr>
		<td><?php echo $res['id'] ?></td>
		<td><?php echo $res['Hourly'] ?></td>
		<td><?php echo $res['HRides'] ?></td>
		<td><?php echo $res['Daywise'] ?></td>
		<td><?php echo $res['DRides'] ?></td>
		<td><?php echo $res['Passengers'] ?></td>
		<td><?php echo $res['Weekly'] ?></td>
		<td><?php echo $res['Rides'] ?></td>
	</tr>
<?php
}

?>
					
				</tbody>
			</table>
</div>
</body>
</html>